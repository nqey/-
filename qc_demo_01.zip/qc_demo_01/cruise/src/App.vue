<template>
  <div id="app">
    <v-header/>
    <router-view class="app-page"/>
  </div>
</template>

<script>
export default {
  name: 'App',
  components: {
    'v-header': () => import('@/components/header')
  }
}
</script>

<style lang="scss">
 @import 'assets/css/common.scss';

 .app-page {
    margin-top: 80px;
 }
</style>
