<template>
  <header class="header" @mouseleave="open = false">
    <div class="layout">
      <img class="logo" src="../../assets/logo/logo.svg">
      <span class="avatar__right" @click="toggle">
        <v-img-circle :diameter="40"/>
        <span class="angle" :class="{ 'icon-angle-up': !open, 'icon-angle-down': open }"/>
      </span>
      <ul class="profile text-left" :class="{ open: open }" @blur="toggle" style="z-index: 999;">
        <router-link tag="li" to="#4" @click.native="toggle">
          <p>
            <span class="icon-id-card"/>profile
          </p>
        </router-link>
        <router-link tag="li" to="#5" @click.native="toggle">
          <p>
            <span class="icon-sign-in"/>Sign Out
          </p>
        </router-link>
      </ul>
    </div>
  </header>
</template>

<script>
export default {
  name: 'lhead',
  data () {
    return {
      open: false
    }
  },
  methods: {
    toggle () {
      this.open = !this.open
    }
  },
  components: {
    'v-img-circle': () => import('@/components/img/circle')
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style type="text/css" lang="scss" scoped>
   @import 'index.scss';
</style>
