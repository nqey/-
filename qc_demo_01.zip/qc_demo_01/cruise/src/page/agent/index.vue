<template>
  <div class="container">
    <v-nav class="nav-left__fixed"/>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
    <div class="row">
      <div class="col-offset-3 col-3">1111111</div>
      <div class="col-3">1111111</div>
      <div class="col-3">1111111</div>
    </div>
  </div>
</template>

<script>
import { getAgentsList, getAgents, upAgents } from '@/config/api'

export default {
  name: 'agent',
  data () {
    return {
      agentList: null,
      agent: null
    }
  },
  components: {
    'v-nav': () => import('@/components/nav')
  },
  methods: {
    async init () {
      this.agentList = await getAgentsList()
    }
  },
  async mounted () {
    this.agent = await getAgents('1')
    this.agent.os = 'windowXXXX'
    await upAgents('1', this.agent)
    window.console.log(this.agentList, this.agent)
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style type="text/css" lang="scss" scoped>
   @import 'index.scss';
</style>
