<template>
  <div class="container">
    <v-nav class="nav-left__fixed"/>
    <div class="row">
      <div class="building col-offset-3 col-3">
        <div class="box box-building">
          <span class="title" style="">Building</span>
          <span class="icon icon-cog"/>
          <span class="number" style="">3</span>
        </div>
      </div>
      <div class="ldle col-3" style="">
        <div class="box box-ldle">
          <span class="title" style="">ldle</span>
          <span class="icon icon-coffee"/>
          <span class="number" style="">5</span>
        </div>
      </div>
      <div class="statistics col-3" style="">
        <div class="box box-statistics" >
          <div class="col-4">
            <span>ALL</span>
          </div>
          <div class="col-4">
            <span>PHYSICAL</span>
          </div>
          <div class="col-4">
            <span>VIRTUAL</span>
          </div>
          <div class="col-4">
            <span>8</span>
          </div>
          <div class="col-4">
            <span>4</span>
          </div>
          <div class="col-4">
            <span>4</span>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="box-search col-offset-3 col-9">
        <div class="col-1" :class="{ active: isSearchActive === 1 }">
          <span>All</span>
        </div>
        <div class="col-1">
          <span>Physical</span>
        </div>
        <div class="col-1">
          <span>Virtual</span>
        </div>
        <div class="col-9">
          <span>VIRTUAL</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getAgentsList, getAgents, upAgents } from '@/config/api'

export default {
  name: 'agent',
  data () {
    return {
      agentList: null,
      agent: null,
      isSearchActive: null
    }
  },
  components: {
    'v-nav': () => import('@/components/nav')
  },
  methods: {
    async init () {
      this.agentList = await getAgentsList()
    }
  },
  async mounted () {
    this.agent = await getAgents('1')
    this.agent.os = 'windowXXXX'
    await upAgents('1', this.agent)
    window.console.log(this.agentList, this.agent)
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style type="text/css" lang="scss" scoped>
  @import 'index.scss';

</style>
